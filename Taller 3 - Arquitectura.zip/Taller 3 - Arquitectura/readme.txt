Materiales del Taller
---------------------

1- Enunciado - Video tutorial - Cómo bajar e instalar Ripes

Enunciado-TallerArquitectura.pdf

2- Manual de Risc-V

http://riscvbook.com/spanish/guia-practica-de-risc-v-1.0.5.pdf

3- Link a la planilla de seguimiento para completar y mostrar a los correctores

https://docs.google.com/spreadsheets/d/1qcSVTS_M9b7n6hwZalqv6j2k8bIRdgh9NfyEWe7k8rs/edit?usp=sharing


